import { PrismaClient, Role, Status, Priority, TimePhase } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Catalogs
  await prisma.material.createMany({
    data: [
      { name: '1018 CRS', spec: 'Steel' },
      { name: '4140', spec: 'Alloy Steel' },
      { name: 'A2', spec: 'Tool Steel' },
      { name: '6061-T6', spec: 'Aluminum' },
      { name: '7075-T6', spec: 'Aluminum' },
      { name: '304SS', spec: 'Stainless' },
      { name: 'Brass 360', spec: 'Brass' },
      { name: 'UHMW', spec: 'Plastic' },
      { name: 'Acetal (Delrin)', spec: 'Plastic' },
    ],
    skipDuplicates: true,
  });

  await prisma.vendor.createMany({
    data: [
      { name: 'McMaster-Carr', url: 'https://www.mcmaster.com' },
      { name: 'OnlineMetals', url: 'https://www.onlinemetals.com' },
      { name: 'Alro Steel', url: 'https://www.alro.com' },
      { name: 'Ryerson', url: 'https://www.ryerson.com' },
    ],
    skipDuplicates: true,
  });

  await prisma.checklistItem.createMany({
    data: [
      { label: 'Deburred' },
      { label: 'Tumbled' },
      { label: 'Sand Blasted' },
      { label: 'Black Oxide' },
      { label: 'Anodized' },
      { label: 'Heat Treat (Hardened)' },
      { label: 'Coated' },
      { label: 'Cleaned & Oiled' },
    ],
    skipDuplicates: true,
  });

  // Users (passwordHash left null; Agent 2 will wire auth)
  const [admin, mach1, mach2, viewer] = await Promise.all([
    prisma.user.upsert({
      where: { email: 'admin@example.com' },
      update: {},
      create: { email: 'admin@example.com', name: 'Admin', role: Role.ADMIN, active: true },
    }),
    prisma.user.upsert({
      where: { email: 'mach1@example.com' },
      update: {},
      create: { email: 'mach1@example.com', name: 'Machinist One', role: Role.MACHINIST, active: true },
    }),
    prisma.user.upsert({
      where: { email: 'mach2@example.com' },
      update: {},
      create: { email: 'mach2@example.com', name: 'Machinist Two', role: Role.MACHINIST, active: true },
    }),
    prisma.user.upsert({
      where: { email: 'viewer@example.com' },
      update: {},
      create: { email: 'viewer@example.com', name: 'Viewer', role: Role.VIEWER, active: true },
    }),
  ]);

  // Customers
  const [corning, toyota, momAndPop] = await Promise.all([
    prisma.customer.create({ data: { name: 'Corning', contact: 'Procurement', email: 'buy@corning.com' } }),
    prisma.customer.create({ data: { name: 'Toyota', contact: 'Tooling', email: 'tooling@toyota.com' } }),
    prisma.customer.create({ data: { name: 'Acme Fab', contact: 'Jess', email: 'jess@acmefab.com' } }),
  ]);

  // Helper lookups
  const mat6061 = await prisma.material.findFirst({ where: { name: '6061-T6' } });
  const mat4140 = await prisma.material.findFirst({ where: { name: '4140' } });
  const matBrass = await prisma.material.findFirst({ where: { name: 'Brass 360' } });
  const vendorMcM = await prisma.vendor.findFirst({ where: { name: 'McMaster-Carr' } });

  // Orders with parts, checklist, etc.
  const order1 = await prisma.order.create({
    data: {
      orderNumber: 'PO-10001',
      customerId: corning.id,
      modelIncluded: true,
      receivedDate: new Date(),
      dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7),
      priority: Priority.NORMAL,
      status: Status.PROGRAMMING,
      assignedMachinistId: mach1.id,
      materialNeeded: true,
      materialOrdered: true,
      vendorId: vendorMcM?.id,
      poNumber: 'MCM-7788123',
      parts: {
        create: [
          { partNumber: 'COR-PLATE-001', quantity: 12, materialId: mat6061?.id || undefined, notes: 'Face + pocket' },
          { partNumber: 'COR-SHAFT-010', quantity: 6, materialId: mat4140?.id || undefined, notes: 'HT after' },
        ],
      },
      checklist: {
        create: [
          ...(
            await prisma.checklistItem.findMany({ where: { label: { in: ['Deburred', 'Anodized'] } } })
          ).map(ci => ({ checklistItemId: ci.id, checked: false })),
        ],
      },
      history: {
        create: [
          { from: Status.RECEIVED, to: Status.PROGRAMMING, userId: admin.id, reason: 'Kicked off programming' },
        ],
      },
      notes: {
        create: [{ userId: mach1.id, content: 'Import STEP and set WCS.' }],
      },
      timeLogs: {
        create: [{ userId: mach1.id, phase: TimePhase.PROGRAMMING, minutes: 45, note: 'Rough toolpaths set' }],
      },
      attachments: {
        create: [{ filename: 'plate.step', url: 'https://example.com/plate.step', mimeType: 'model/step', uploadedById: admin.id }],
      },
    },
  });

  const order2 = await prisma.order.create({
    data: {
      orderNumber: 'PO-10002',
      customerId: toyota.id,
      modelIncluded: false,
      receivedDate: new Date(),
      dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 3),
      priority: Priority.HOT,
      status: Status.SETUP,
      assignedMachinistId: mach2.id,
      materialNeeded: false,
      materialOrdered: false,
      parts: {
        create: [
          { partNumber: 'TYT-BRKT-220', quantity: 20, materialId: mat6061?.id || undefined, notes: 'Chamfers critical' },
        ],
      },
      checklist: {
        create: [
          ...(
            await prisma.checklistItem.findMany({ where: { label: { in: ['Deburred', 'Tumbled'] } } })
          ).map(ci => ({ checklistItemId: ci.id, checked: false })),
        ],
      },
      history: {
        create: [
          { from: Status.RECEIVED, to: Status.PROGRAMMING, userId: admin.id },
          { from: Status.PROGRAMMING, to: Status.SETUP, userId: mach2.id, reason: 'Programs posted' },
        ],
      },
      notes: { create: [{ userId: mach2.id, content: 'Jaws cut. Indicated in.' }] },
      timeLogs: {
        create: [
          { userId: mach2.id, phase: TimePhase.PROGRAMMING, minutes: 30 },
          { userId: mach2.id, phase: TimePhase.SETUP, minutes: 55 },
        ],
      },
    },
  });

  const order3 = await prisma.order.create({
    data: {
      orderNumber: 'PO-10003',
      customerId: momAndPop.id,
      modelIncluded: true,
      receivedDate: new Date(),
      dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 14),
      priority: Priority.LOW,
      status: Status.RECEIVED,
      assignedMachinistId: mach1.id,
      materialNeeded: true,
      materialOrdered: false,
      vendorId: vendorMcM?.id,
      parts: {
        create: [
          { partNumber: 'ACM-PIN-05', quantity: 200, materialId: matBrass?.id || undefined, notes: 'Tight press fit' },
        ],
      },
      checklist: {
        create: [
          ...(
            await prisma.checklistItem.findMany({ where: { label: { in: ['Deburred', 'Cleaned & Oiled'] } } })
          ).map(ci => ({ checklistItemId: ci.id, checked: false })),
        ],
      },
      notes: { create: [{ userId: admin.id, content: 'Small shop rush if possible; keep cost down.' }] },
    },
  });

  console.log('Seed complete:', {
    users: [admin.email, mach1.email, mach2.email, viewer.email],
    orders: [order1.orderNumber, order2.orderNumber, order3.orderNumber]
  });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
