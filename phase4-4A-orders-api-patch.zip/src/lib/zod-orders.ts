import { z } from 'zod';

export const StatusEnum = z.enum(['RECEIVED','PROGRAMMING','SETUP','RUNNING','FINISHING','DONE_MACHINING','INSPECTION','SHIPPING','CLOSED']);
export const PriorityEnum = z.enum(['LOW','NORMAL','RUSH','HOT']);

export const OrderPartCreate = z.object({
  partNumber: z.string().trim().min(1),
  quantity: z.coerce.number().int().min(1),
  materialId: z.string().trim().optional(),
  notes: z.string().trim().max(500).optional(),
});

export const OrderCreate = z.object({
  orderNumber: z.string().trim().min(1),
  customerId: z.string().trim().min(1),
  modelIncluded: z.boolean().default(false),
  receivedDate: z.string().min(1),
  dueDate: z.string().min(1),
  priority: PriorityEnum.default('NORMAL'),
  materialNeeded: z.boolean().default(false),
  materialOrdered: z.boolean().default(false),
  vendorId: z.string().optional(),
  poNumber: z.string().optional(),
  assignedMachinistId: z.string().optional(),
  parts: z.array(OrderPartCreate).min(1),
  checklistItemIds: z.array(z.string()).optional(),
  attachments: z.array(z.object({ filename: z.string().min(1), url: z.string().url(), mimeType: z.string().optional() })).optional(),
});

export const OrdersListQuery = z.object({
  q: z.string().optional(),
  status: z.string().optional(), // comma list
  assignedMachinistId: z.string().optional(),
  customerId: z.string().optional(),
  overdue: z.coerce.number().optional(),
  awaitingMaterial: z.coerce.number().optional(),
  priority: z.string().optional(), // comma list
  take: z.coerce.number().int().min(1).max(50).default(20),
  cursor: z.string().optional(),
});