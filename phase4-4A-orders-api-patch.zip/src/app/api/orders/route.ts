import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '../../../lib/prisma';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../../lib/auth';
import { canAccessAdmin } from '../../../lib/rbac';
import { OrdersListQuery, OrderCreate } from '../../../lib/zod-orders';

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const params = Object.fromEntries(url.searchParams.entries());
  const parsed = OrdersListQuery.safeParse(params);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const { q, status, assignedMachinistId, customerId, overdue, awaitingMaterial, priority, take, cursor } = parsed.data;

  const where: any = {};
  if (q) where.OR = [{ orderNumber: { contains: q, mode: 'insensitive' } }, { customer: { name: { contains: q, mode: 'insensitive' } } }];
  if (status) where.status = { in: status.split(',') };
  if (assignedMachinistId) where.assignedMachinistId = assignedMachinistId;
  if (customerId) where.customerId = customerId;
  if (priority) where.priority = { in: priority.split(',') };
  if (overdue) where.dueDate = { lt: new Date() };
  if (awaitingMaterial) where.materialNeeded = true;

  const items = await prisma.order.findMany({
    where,
    orderBy: [{ dueDate: 'asc' }, { priority: 'desc' }],
    take,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    select: { id: true, orderNumber: true, customer: { select: { name: true } }, dueDate: true, status: true, priority: true, assignedMachinist: { select: { name: true, id: true } } },
  });
  const nextCursor = items.length === take ? items[items.length - 1].id : null;
  return NextResponse.json({ items, nextCursor });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  const role = (session?.user as any)?.role;
  if (!session) return new NextResponse('Unauthorized', { status: 401 });
  if (!canAccessAdmin(role)) return new NextResponse('Forbidden', { status: 403 });

  const body = await req.json();
  const parsed = OrderCreate.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  const data = parsed.data;

  const created = await prisma.order.create({
    data: {
      orderNumber: data.orderNumber,
      customerId: data.customerId,
      modelIncluded: data.modelIncluded,
      receivedDate: new Date(data.receivedDate),
      dueDate: new Date(data.dueDate),
      priority: data.priority as any,
      status: 'RECEIVED',
      assignedMachinistId: data.assignedMachinistId || null,
      materialNeeded: data.materialNeeded,
      materialOrdered: data.materialOrdered,
      vendorId: data.vendorId || null,
      poNumber: data.poNumber || null,
      parts: { create: data.parts.map(p => ({ partNumber: p.partNumber, quantity: p.quantity, materialId: p.materialId || null, notes: p.notes || null })) },
      checklist: data.checklistItemIds ? { create: data.checklistItemIds.map(id => ({ checklistItemId: id, checked: false })) } : undefined,
      attachments: data.attachments ? { create: data.attachments.map(a => ({ filename: a.filename, url: a.url, mimeType: a.mimeType })) } : undefined,
      history: { create: [{ from: 'RECEIVED', to: 'RECEIVED', userId: (session.user as any)?.id || 'unknown' }] },
    },
    select: { id: true },
  });

  return NextResponse.json({ ok: true, id: created.id });
}